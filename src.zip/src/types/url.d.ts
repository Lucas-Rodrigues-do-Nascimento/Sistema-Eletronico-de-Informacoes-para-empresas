declare module '*?url' {
    const src: string
    export default src
  }
  