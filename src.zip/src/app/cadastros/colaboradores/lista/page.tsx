'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'
import Link from 'next/link'

type Colaborador = {
  id: number
  nome: string
  email: string
  telefone: string
  cargo: string
  ativo: boolean
  setor: {
    id: number
    nome: string
  }
}

export default function ListaColaboradoresPage() {
  const [colaboradores, setColaboradores] = useState<Colaborador[]>([])

  useEffect(() => {
    fetch('/api/colaboradores')
      .then((res) => res.json())
      .then((data) => setColaboradores(data))
      .catch((err) => {
        console.error(err)
        toast.error('Erro ao carregar colaboradores')
      })
  }, [])

  const handleInativar = async (id: number, ativo: boolean) => {
    try {
      const res = await fetch(`/api/colaboradores/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ativo: !ativo }),
      })

      if (!res.ok) throw new Error()
      toast.success('Status alterado com sucesso!')
      setColaboradores((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, ativo: !c.ativo } : c
        )
      )
    } catch (err) {
      toast.error('Erro ao alterar status do colaborador')
    }
  }

  const colaboradoresPorSetor = colaboradores.reduce((acc, colab) => {
    const setorId = colab.setor.id
    if (!acc[setorId]) acc[setorId] = { nome: colab.setor.nome, colaboradores: [] }
    acc[setorId].colaboradores.push(colab)
    return acc
  }, {} as Record<number, { nome: string; colaboradores: Colaborador[] }>)

  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">👥 Colaboradores</h1>
        <Link href="/cadastros/colaboradores">
          <Button variant="outline">← Novo Colaborador</Button>
        </Link>
      </div>

      {Object.entries(colaboradoresPorSetor).map(([id, grupo]) => (
        <div key={id} className="space-y-3">
          <h2 className="text-xl font-semibold text-indigo-700 mt-6">
            Setor: {grupo.nome}
          </h2>
          {grupo.colaboradores.map((c) => (
            <Card key={c.id}>
              <CardContent className="p-4 flex justify-between items-center">
                <div>
                  <h3 className="font-bold">{c.nome}</h3>
                  <p className="text-sm text-gray-600">
                    {c.email} · {c.telefone} · {c.cargo}
                  </p>
                  <p className="text-xs text-gray-500">
                    Status: {c.ativo ? 'Ativo' : 'Inativo'}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline">Editar</Button>
                  <Button
                    variant="outline"
                    onClick={() => handleInativar(c.id, c.ativo)}
                  >
                    {c.ativo ? 'Inativar' : 'Ativar'}
                  </Button>
                  <Button variant="outline">Alterar Senha</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ))}
    </div>
  )
}
