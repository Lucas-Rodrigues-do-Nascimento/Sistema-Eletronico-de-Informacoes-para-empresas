// src/app/api/documento/[docId]/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(
  request: Request,
  { params }: { params: { docId: string } }
) {
  const formData = await request.formData();
  const conteudo = formData.get("conteudo") as string;

  // Atualiza o documento no banco de dados
  const updatedDocumento = await prisma.documento.update({
    where: { id: Number(params.docId) },
    data: { conteudo },
  });

  // Redireciona de volta para a página de detalhes do processo
  const redirectUrl = new URL(
    `/controle-de-processos/${updatedDocumento.processoId}`,
    request.url
  );
  return NextResponse.redirect(redirectUrl);
}
