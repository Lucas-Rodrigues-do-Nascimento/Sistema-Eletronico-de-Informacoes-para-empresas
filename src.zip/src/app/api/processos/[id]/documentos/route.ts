import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const processoId = Number(params.id)
  if (isNaN(processoId) || processoId <= 0) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  try {
    const docs = await prisma.documento.findMany({
      where: { processoId },
      orderBy: { criadoEm: 'asc' },
      select: { id: true, nome: true, tipo: true, criadoEm: true }
    })

    return NextResponse.json(docs)
  } catch (err) {
    console.error('[GET /api/processos/[id]/documentos]', err)
    return NextResponse.json({ error: 'Erro ao carregar documentos.' }, { status: 500 })
  }
}

export async function POST(
  request: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const processoId = Number(params.id)
  if (isNaN(processoId) || processoId <= 0) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  const formData = await request.formData()
  const file = formData.get('file') as File
  const tipo = formData.get('tipo')?.toString() || 'externo'

  if (!file || !file.name) {
    return NextResponse.json({ error: 'Arquivo inválido.' }, { status: 400 })
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer())
    const base64 = buffer.toString('base64')

    const doc = await prisma.documento.create({
      data: {
        nome: file.name,
        tipo,
        conteudo: base64,
        processoId,
      },
    })

    return NextResponse.json(doc)
  } catch (err) {
    console.error('[POST /api/processos/[id]/documentos]', err)
    return NextResponse.json({ error: 'Erro ao salvar documento.' }, { status: 500 })
  }
}
