import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET(
  request: NextRequest,
  context: Awaited<{ params: { id: string; docId: string } }>
) {
  const { params } = await context
  const processoId = Number(params.id)
  const docId = Number(params.docId)

  if (isNaN(processoId) || isNaN(docId)) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  const doc = await prisma.documento.findUnique({
    where: { id: docId },
    select: { conteudo: true, nome: true, processoId: true }
  })

  if (!doc || doc.processoId !== processoId) {
    return NextResponse.json({ error: 'Documento não encontrado' }, { status: 404 })
  }

  if (!doc.conteudo) {
    return NextResponse.json({ error: 'Conteúdo do documento não encontrado' }, { status: 404 })
  }

  return new NextResponse(Buffer.from(doc.conteudo, 'base64'), {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="${doc.nome}"`
    }
  })
}
