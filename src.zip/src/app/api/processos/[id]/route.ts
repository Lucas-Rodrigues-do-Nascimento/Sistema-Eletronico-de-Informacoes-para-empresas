import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const id = Number(params.id)

  if (isNaN(id) || id <= 0) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  try {
    const processo = await prisma.processo.findUnique({
      where: { id },
      include: {
        movimentacoes: {
          orderBy: { criadoEm: 'desc' },
          include: {
            de: { select: { nome: true } },
            para: { select: { nome: true } },
          },
        },
      },
    })

    if (!processo) {
      return NextResponse.json({ error: 'Processo não encontrado' }, { status: 404 })
    }

    return NextResponse.json(processo)
  } catch (err) {
    console.error('[GET /api/processos/[id]]', err)
    return NextResponse.json({ error: 'Erro interno.' }, { status: 500 })
  }
}
