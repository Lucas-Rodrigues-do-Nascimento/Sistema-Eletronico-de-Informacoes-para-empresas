import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const processoId = Number(params.id)

  if (isNaN(processoId) || processoId <= 0) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  try {
    const historico = await prisma.movimentacao.findMany({
      where: { processoId },
      orderBy: { criadoEm: 'desc' },
      include: {
        de:   { select: { nome: true } },
        para: { select: { nome: true } },
      },
    })
    return NextResponse.json(historico)
  } catch (err) {
    console.error('[GET /api/processos/[id]/historico]', err)
    return NextResponse.json({ error: 'Erro ao carregar histórico.' }, { status: 500 })
  }
}
