import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

// POST: Criar um novo processo e registrar movimentação inicial
export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)
    const user = session?.user

    if (!user || !user.setor) {
      return NextResponse.json(
        { error: 'Usuário não autenticado ou sem setor definido.' },
        { status: 401 }
      )
    }

    const data = await req.json()

    // Cria o processo
    const processo = await prisma.processo.create({
      data: {
        tipo: data.tipo,
        especificacao: data.especificacao,
        interessado: data.interessado,
        observacoes: data.observacoes || null,
        acesso: data.acesso,
      },
    })

    // Cria movimentação inicial vinculada ao setor atual
    await prisma.movimentacao.create({
      data: {
        processoId: processo.id,
        deSetor: String(user.setor),
        paraSetor: String(user.setor),
        observacoes: 'Movimentação inicial automática',
        manterAbertoNoSetorOrigem: true,
        ativo: true,
      },
    })

    return NextResponse.json(processo)
  } catch (error) {
    console.error('❌ Erro ao criar processo:', error)
    return new NextResponse('Erro interno', { status: 500 })
  }
}
