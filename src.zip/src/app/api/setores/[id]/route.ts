import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

// PUT: Atualiza um setor
export async function PUT(
  req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const id = Number(params.id)
  const { nome, unidadeId } = await req.json()

  if (!nome || !unidadeId) {
    return NextResponse.json(
      { error: 'Nome e unidade são obrigatórios' },
      { status: 400 }
    )
  }

  try {
    const setorAtualizado = await prisma.setor.update({
      where: { id },
      data: {
        nome,
        unidadeId: Number(unidadeId),
      },
    })

    return NextResponse.json(setorAtualizado)
  } catch (err) {
    console.error('Erro ao atualizar setor:', err)
    return new NextResponse('Erro interno ao atualizar setor', { status: 500 })
  }
}

// DELETE: Remove um setor
export async function DELETE(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context
  const id = Number(params.id)

  try {
    await prisma.setor.delete({ where: { id } })
    return new NextResponse(null, { status: 204 })
  } catch (err) {
    console.error('Erro ao excluir setor:', err)
    return new NextResponse('Erro interno ao excluir setor', { status: 500 })
  }
}
