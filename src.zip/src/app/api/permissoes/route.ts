// src/app/api/permissoes/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET → Lista todas as permissões
export async function GET() {
  try {
    const permissoes = await prisma.permissao.findMany({
      orderBy: { nome: "asc" },
    });
    return NextResponse.json(permissoes);
  } catch (error) {
    console.error("Erro ao buscar permissões:", error);
    return new NextResponse("Erro ao buscar permissões", { status: 500 });
  }
}

// POST → Cria uma nova permissão
export async function POST(req: Request) {
  try {
    const { nome, descricao, codigo } = await req.json();

    if (!nome || !codigo) {
      return NextResponse.json({ error: "Nome e código são obrigatórios" }, { status: 400 });
    }

    const nova = await prisma.permissao.create({
      data: { nome, descricao, codigo },
    });

    return NextResponse.json(nova, { status: 201 });
  } catch (error) {
    console.error("Erro ao criar permissão:", error);
    return new NextResponse("Erro ao criar permissão", { status: 500 });
  }
}
