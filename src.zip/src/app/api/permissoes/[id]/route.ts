import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

/* ────────────────  GET  ──────────────── */
export async function GET(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context;
  const id = Number(params.id);

  if (isNaN(id)) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 });
  }

  try {
    const permissao = await prisma.permissao.findUnique({ where: { id } });
    if (!permissao) {
      return NextResponse.json(
        { error: 'Permissão não encontrada' },
        { status: 404 }
      );
    }
    return NextResponse.json(permissao);
  } catch (err) {
    console.error('[GET /api/permissoes/[id]]', err);
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 });
  }
}

/* ────────────────  PUT  ──────────────── */
export async function PUT(
  req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context;
  const id = Number(params.id);

  if (isNaN(id)) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 });
  }

  const { nome, descricao } = await req.json();

  if (!nome) {
    return NextResponse.json({ error: 'Nome é obrigatório' }, { status: 400 });
  }

  try {
    const atualizada = await prisma.permissao.update({
      where: { id },
      data: { nome, descricao },
    });
    return NextResponse.json(atualizada);
  } catch (err) {
    console.error('[PUT /api/permissoes/[id]]', err);
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 });
  }
}

/* ───────────────  DELETE ─────────────── */
export async function DELETE(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context;
  const id = Number(params.id);

  if (isNaN(id)) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 });
  }

  try {
    await prisma.permissao.delete({ where: { id } });
    return new NextResponse(null, { status: 204 });
  } catch (err) {
    console.error('[DELETE /api/permissoes/[id]]', err);
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 });
  }
}
