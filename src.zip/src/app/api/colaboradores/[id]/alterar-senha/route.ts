import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import bcrypt from 'bcryptjs'

export const dynamic = 'force-dynamic'

export async function PATCH(
  req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context          // ✅ await exigido
  const colaboradorId = Number(params.id)
  const { novaSenha } = await req.json()

  if (isNaN(colaboradorId) || !novaSenha) {
    return NextResponse.json(
      { error: 'ID e nova senha são obrigatórios.' },
      { status: 400 }
    )
  }

  try {
    const senhaCriptografada = await bcrypt.hash(novaSenha, 10)

    await prisma.colaborador.update({
      where: { id: colaboradorId },
      data: { senha: senhaCriptografada },
    })

    return NextResponse.json({ message: 'Senha atualizada com sucesso' })
  } catch (err) {
    console.error('[PATCH /api/colaboradores/[id]/alterar-senha]', err)
    return NextResponse.json(
      { error: 'Erro ao alterar senha.' },
      { status: 500 }
    )
  }
}
