import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function PATCH(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  try {
    const { params } = await context        // ✅ await exigido
    const colaboradorId = Number(params.id)

    if (isNaN(colaboradorId)) {
      return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
    }

    const colaborador = await prisma.colaborador.findUnique({
      where: { id: colaboradorId },
    })

    if (!colaborador) {
      return NextResponse.json(
        { error: 'Colaborador não encontrado' },
        { status: 404 }
      )
    }

    const atualizado = await prisma.colaborador.update({
      where: { id: colaboradorId },
      data: { ativo: !colaborador.ativo },
    })

    return NextResponse.json(atualizado)
  } catch (err) {
    console.error('[PATCH /api/colaboradores/[id]/toggle-ativo]', err)
    return NextResponse.json(
      { error: 'Erro ao atualizar status' },
      { status: 500 }
    )
  }
}
