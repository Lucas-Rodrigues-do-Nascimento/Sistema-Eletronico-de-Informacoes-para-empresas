import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function PATCH(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context          // ✅ await exigido
  const colaboradorId = Number(params.id)

  if (isNaN(colaboradorId)) {
    return NextResponse.json(
      { error: 'ID do colaborador é obrigatório.' },
      { status: 400 }
    )
  }

  try {
    const colaborador = await prisma.colaborador.findUnique({
      where: { id: colaboradorId },
    })

    if (!colaborador) {
      return NextResponse.json(
        { error: 'Colaborador não encontrado.' },
        { status: 404 }
      )
    }

    const atualizado = await prisma.colaborador.update({
      where: { id: colaboradorId },
      data: { ativo: !colaborador.ativo },   // alterna status
    })

    return NextResponse.json(atualizado, { status: 200 })
  } catch (err) {
    console.error('[PATCH /api/colaboradores/[id]/inativar]', err)
    return NextResponse.json(
      { error: 'Erro interno ao atualizar colaborador' },
      { status: 500 }
    )
  }
}
