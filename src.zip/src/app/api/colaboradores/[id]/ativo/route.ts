import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function PATCH(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context          // ✅ await obrigatório
  const colaboradorId = Number(params.id)

  if (isNaN(colaboradorId)) {
    return NextResponse.json({ error: 'ID inválido.' }, { status: 400 })
  }

  try {
    const colaborador = await prisma.colaborador.findUnique({
      where: { id: colaboradorId },
    })

    if (!colaborador) {
      return NextResponse.json(
        { error: 'Colaborador não encontrado.' },
        { status: 404 }
      )
    }

    const atualizado = await prisma.colaborador.update({
      where: { id: colaborador.id },
      data: { ativo: !colaborador.ativo },
    })

    return NextResponse.json(atualizado)
  } catch (err) {
    console.error('[PATCH /api/colaboradores/[id]/ativo]', err)
    return NextResponse.json(
      { error: 'Erro interno ao alternar status.' },
      { status: 500 }
    )
  }
}
