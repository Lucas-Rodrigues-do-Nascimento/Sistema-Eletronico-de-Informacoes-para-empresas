import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

/* ─────────────  PATCH – editar colaborador ───────────── */
export async function PATCH(
  req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context        // ✅ aguarda o contexto
  const colaboradorId = Number(params.id)

  const {
    nome,
    email,
    cpf,
    telefone,
    cargo,
    setorId,
    permissaoId,
  } = await req.json()

  if (
    isNaN(colaboradorId) ||
    !nome || !email || !cpf || !setorId || !permissaoId
  ) {
    return NextResponse.json(
      { error: 'Campos obrigatórios não preenchidos.' },
      { status: 400 }
    )
  }

  try {
    const colaborador = await prisma.colaborador.update({
      where: { id: colaboradorId },
      data: {
        nome,
        email,
        cpf,
        telefone,
        cargo,
        setorId: Number(setorId),
        permissaoId: Number(permissaoId),
      },
    })

    return NextResponse.json(colaborador, { status: 200 })
  } catch (err) {
    console.error('[PATCH /api/colaboradores/[id]]', err)
    return NextResponse.json(
      { error: 'Erro interno ao atualizar colaborador.' },
      { status: 500 }
    )
  }
}

/* ─────────────  DELETE – excluir colaborador ───────────── */
export async function DELETE(
  _req: Request,
  context: Awaited<{ params: { id: string } }>
) {
  const { params } = await context        // ✅ aguarda o contexto
  const colaboradorId = Number(params.id)

  if (isNaN(colaboradorId)) {
    return NextResponse.json({ error: 'ID inválido' }, { status: 400 })
  }

  try {
    await prisma.colaborador.delete({ where: { id: colaboradorId } })
    return NextResponse.json({ message: 'Colaborador excluído com sucesso' })
  } catch (err) {
    console.error('[DELETE /api/colaboradores/[id]]', err)
    return NextResponse.json(
      { error: 'Erro ao excluir colaborador' },
      { status: 500 }
    )
  }
}
