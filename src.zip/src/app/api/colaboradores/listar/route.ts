// src/app/api/colaboradores/listar/route.ts
import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    const colaboradores = await prisma.colaborador.findMany({
      include: {
        setor: true,
      },
      orderBy: {
        nome: 'asc',
      },
    })

    return NextResponse.json(colaboradores)
  } catch (error) {
    console.error('Erro ao listar colaboradores:', error)
    return new NextResponse('Erro ao listar colaboradores', { status: 500 })
  }
}
