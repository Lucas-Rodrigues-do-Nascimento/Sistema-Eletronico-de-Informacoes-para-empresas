// src/app/controle-de-processos/[id]/editar-documento/[docId]/page.tsx
import { notFound } from "next/navigation";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

interface Props {
  params: {
    id: string;      // ID do processo
    docId: string;   // ID do documento a editar
  };
}

export default async function EditDocumentoPage({ params }: Props) {
  const awaitedParams = await Promise.resolve(params);
  const documento = await prisma.documento.findUnique({
    where: { id: Number(awaitedParams.docId) },
  });

  if (!documento || documento.tipo !== "criado") return notFound();

  return (
    <form
      action={`/api/documento/${documento.id}`}
      method="POST"
      className="max-w-3xl mx-auto py-10 px-4 space-y-4"
    >
      <h1 className="text-xl font-bold text-gray-800">Editar Documento Interno</h1>
      <input type="hidden" name="docId" value={documento.id} />
      <Textarea
        name="conteudo"
        defaultValue={documento.conteudo || ""}
        rows={16}
        className="w-full border rounded p-2 text-sm"
      />
      <Button type="submit" className="bg-indigo-600 text-white hover:bg-indigo-700">
        Salvar Alterações
      </Button>
    </form>
  );
}
