// src/app/controle-de-processos/[id]/novo-documento/page.tsx
import { notFound } from 'next/navigation'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'

export const dynamic = 'force-dynamic'

const modelosPredefinidos: Record<string, string> = {
  memorando: 'MEMORANDO INTERNO\n\nDe: [Remetente]...\nPara: [Destinatário]...\nAssunto: ...',
  requisicao: 'REQUISIÇÃO DE COMPRAS\n\nItem: ...\nQuantidade: ...\nJustificativa: ...',
  ordem: 'ORDEM DE SERVIÇO\n\nServiço a ser executado: ...',
  justificativa: 'JUSTIFICATIVA TÉCNICA\n\n[Descreva a justificativa...]',
  pagamento: 'SOLICITAÇÃO DE PAGAMENTO\n\nFavorecido: ...\nValor: ...\nData de vencimento: ...',
  despacho: 'DESPACHO / PARECER\n\n[Digite aqui o conteúdo do despacho...]',
}

export default async function NovoDocumentoPage(
  context: Awaited<{ params: { id: string }, searchParams: { [key: string]: string | string[] | undefined } }>
) {
  const { params, searchParams } = await context
  const modeloParam = searchParams?.modelo
  const modelo = Array.isArray(modeloParam) ? modeloParam[0] : modeloParam || 'memorando'
  const conteudoPadrao = modelosPredefinidos[modelo]

  if (!conteudoPadrao) return notFound()

  return (
    <form
      action={`/api/novo-documento/${params.id}`}
      method="POST"
      className="max-w-3xl mx-auto py-10 px-4 space-y-4"
    >
      <h1 className="text-xl font-bold text-gray-800">
        Novo Documento - {modelo.replace('-', ' ').toUpperCase()}
      </h1>

      <input type="hidden" name="tipo" value={modelo} />

      <Textarea
        name="conteudo"
        defaultValue={conteudoPadrao}
        rows={16}
        className="w-full border rounded p-2 text-sm"
      />

      <Button type="submit" className="bg-indigo-600 text-white hover:bg-indigo-700">
        Salvar Documento
      </Button>
    </form>
  )
}
