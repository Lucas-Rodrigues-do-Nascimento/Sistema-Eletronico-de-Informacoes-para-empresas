'use client'

import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

interface Setor {
  id: number
  nome: string
}

interface Permissao {
  id: number
  nome: string
}

interface Colaborador {
  id: number
  nome: string
  email: string
  cpf: string
  telefone: string
  cargo: string
  setor: { id: number }
  permissao: { id: number }
}

interface ModalEditarColaboradorProps {
  open: boolean
  onClose: () => void
  colaborador: Colaborador
  setores: Setor[]
  permissoes: Permissao[]
  onAtualizado: () => void
}

export default function ModalEditarColaborador({
  open,
  onClose,
  colaborador,
  setores,
  permissoes,
  onAtualizado,
}: ModalEditarColaboradorProps) {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [cpf, setCpf] = useState('')
  const [telefone, setTelefone] = useState('')
  const [cargo, setCargo] = useState('')
  const [setorId, setSetorId] = useState<number | ''>('')
  const [permissaoId, setPermissaoId] = useState<number | ''>('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (colaborador) {
      setNome(colaborador.nome)
      setEmail(colaborador.email)
      setCpf(colaborador.cpf)
      setTelefone(colaborador.telefone)
      setCargo(colaborador.cargo)
      setSetorId(colaborador.setor?.id ?? '')
      setPermissaoId(colaborador.permissao?.id ?? '')
    }
  }, [colaborador])

  async function handleSalvar() {
    setLoading(true)

    try {
      const res = await fetch(`/api/colaboradores/${colaborador.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome,
          email,
          cpf,
          telefone,
          cargo,
          setorId,
          permissaoId,
        }),
      })

      if (!res.ok) throw new Error('Erro ao atualizar colaborador')

      toast.success('✅ Colaborador atualizado com sucesso!')
      onClose()
      onAtualizado()
    } catch (err) {
      console.error(err)
      toast.error('❌ Erro ao atualizar colaborador')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>✏️ Editar Colaborador</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div>
            <Label htmlFor="nome">Nome</Label>
            <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} disabled={loading} />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={loading} />
          </div>

          <div>
            <Label htmlFor="cpf">CPF</Label>
            <Input id="cpf" value={cpf} onChange={(e) => setCpf(e.target.value)} disabled={loading} />
          </div>

          <div>
            <Label htmlFor="telefone">Telefone</Label>
            <Input id="telefone" value={telefone} onChange={(e) => setTelefone(e.target.value)} disabled={loading} />
          </div>

          <div>
            <Label htmlFor="cargo">Cargo</Label>
            <Input id="cargo" value={cargo} onChange={(e) => setCargo(e.target.value)} disabled={loading} />
          </div>

          <div>
            <Label htmlFor="setor">Setor</Label>
            <select
              id="setor"
              value={setorId}
              onChange={(e) => setSetorId(Number(e.target.value))}
              className="w-full border rounded px-3 py-2 text-sm"
              disabled={loading}
            >
              <option value="">Selecione o setor</option>
              {setores.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <Label htmlFor="permissao">Permissão</Label>
            <select
              id="permissao"
              value={permissaoId}
              onChange={(e) => setPermissaoId(Number(e.target.value))}
              className="w-full border rounded px-3 py-2 text-sm"
              disabled={loading}
            >
              <option value="">Selecione a permissão</option>
              {permissoes.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.nome}
                </option>
              ))}
            </select>
          </div>

          <div className="pt-2">
            <Button onClick={handleSalvar} className="w-full" disabled={loading}>
              {loading ? 'Salvando...' : 'Salvar Alterações'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
