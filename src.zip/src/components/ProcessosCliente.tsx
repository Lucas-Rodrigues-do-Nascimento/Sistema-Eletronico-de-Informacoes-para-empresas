'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  FilePlus,
  ArrowLeftRight,
  FileDown,
  Users,
  Archive,
  ChevronDown
} from 'lucide-react'
import Link from 'next/link'
import UploadDocumentoExterno from '@/components/UploadDocumentoExterno'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger
} from '@/components/ui/dropdown-menu'

interface Documento {
  id: number
  nome: string
  tipo: string
  criadoEm: string
}
interface Movimentacao {
  id: number
  de?: { nome: string }
  para?: { nome: string }
  criadoEm: string
}
interface Processo {
  id: number
  tipo: string
  especificacao: string
  interessado: string
  acesso: string
  criadoEm: string
}

interface Props {
  processoId: string
}

export default function ProcessosCliente({ processoId }: Props) {
  const id = Number(processoId)
  const router = useRouter()
  const [processo, setProcesso] = useState<Processo | null>(null)
  const [documentos, setDocumentos] = useState<Documento[]>([])
  const [historico, setHistorico] = useState<Movimentacao[]>([])
  const [selected, setSelected] = useState<Documento | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function load() {
      try {
        const [pRes, dRes, hRes] = await Promise.all([
          fetch(`/api/processos/${id}`),
          fetch(`/api/processos/${id}/documentos`),
          fetch(`/api/processos/${id}/historico`)
        ])
        if (!pRes.ok) throw new Error('Falha ao carregar processo')
        if (!dRes.ok) throw new Error('Falha ao carregar documentos')
        if (!hRes.ok) throw new Error('Falha ao carregar histórico')
        setProcesso(await pRes.json())
        setDocumentos(await dRes.json())
        setHistorico(await hRes.json())
      } catch (e: any) {
        console.error(e)
        setError(e.message)
      } finally {
        setLoading(false)
      }
    }
    if (!isNaN(id) && id > 0) load()
    else {
      setError('ID de processo inválido')
      setLoading(false)
    }
  }, [id])

  const renderDocumento = (doc: Documento) => {
    const isPDF = doc.nome.toLowerCase().endsWith('.pdf')
    return (
      <div key={doc.id} className="flex-1 overflow-auto bg-white shadow p-4">
        {isPDF ? (
          <iframe
            src={`/api/processos/${id}/documentos/${doc.id}`}
            title={doc.nome}
            width="100%"
            height="100%"
            className="w-full h-full border rounded"
          />
        ) : (
          <iframe
            src={`/api/processos/${id}/documentos/${doc.id}`}
            title={doc.nome}
            className="w-full h-full min-h-[400px] border rounded"
          />
        )}
      </div>
    )
  }

  if (loading) return <div className="p-4">Carregando…</div>
  if (error) return <div className="p-4 text-red-600">{error}</div>
  if (!processo) return <div className="p-4">Processo não encontrado</div>

  return (
    <div className="flex h-screen">
      <aside className="w-1/4 border-r bg-white p-4 overflow-auto">
        <button
          onClick={() => setSelected(null)}
          className="w-full text-left font-semibold mb-4 hover:underline"
        >
          Processo #{processo.id}
        </button>
        <ul className="space-y-2">
          {documentos.map(doc => (
            <li
              key={doc.id}
              onClick={() => setSelected(doc)}
              className={`p-2 rounded cursor-pointer hover:bg-gray-100 ${selected?.id === doc.id ? 'bg-gray-200' : ''}`}
            >{doc.nome}</li>
          ))}
        </ul>
      </aside>

      <div className="flex flex-col flex-1 p-6 overflow-auto">
        <div className="flex flex-wrap gap-2 mb-4">
          <Button variant="ghost" onClick={() => router.push('/controle-de-processos')}>← Voltar</Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="flex items-center gap-1"><FilePlus className="w-4 h-4"/> Incluir Documento <ChevronDown className="w-4 h-4"/></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>📎 Externo</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem asChild><UploadDocumentoExterno processoId={processo.id} /></DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>📝 Interno</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  {[
                    ['memorando','📄 Memorando'],['requisicao','🛒 Requisição'],['ordem','🧾 Ordem'],['justificativa','📑 Justificativa'],['pagamento','💰 Pagamento'],['despacho','📌 Despacho']
                  ].map(([m,l]) => (
                    <DropdownMenuItem asChild key={m}>
                      <Link href={`/controle-de-processos/${processo.id}/novo-documento?modelo=${m}`}>{l}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuSubContent>
              </DropdownMenuSub>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" onClick={() => router.push(`/controle-de-processos/${processo.id}/tramitar`)} className="flex items-center gap-1"><ArrowLeftRight className="w-4 h-4"/> Trâmite</Button>
          <Button variant="outline" className="flex items-center gap-1"><FileDown className="w-4 h-4"/> Baixar</Button>
          <Button variant="outline" className="flex items-center gap-1"><Users className="w-4 h-4"/> Acessos</Button>
          <Button variant="outline" className="flex items-center gap-1"><Archive className="w-4 h-4"/> Arquivar</Button>
        </div>

        {selected ? (
          renderDocumento(selected)
        ) : (
          <>
            <Card className="mb-4"><CardContent>
              <h2 className="text-xl font-semibold mb-2">Detalhes do Processo</h2>
              <p><strong>Tipo:</strong> {processo.tipo}</p>
              <p><strong>Interessado:</strong> {processo.interessado}</p>
              <p><strong>Acesso:</strong> {processo.acesso}</p>
              <p><strong>Criado em:</strong> {new Date(processo.criadoEm).toLocaleString()}</p>
            </CardContent></Card>
            <Card><CardContent>
              <h2 className="text-xl font-semibold mb-2">Histórico</h2>
              <table className="w-full text-sm"><thead><tr><th>De</th><th>Para</th><th>Data</th></tr></thead><tbody>
                {historico.map(h => (
                  <tr key={h.id} className="border-t"><td>{h.de?.nome||'—'}</td><td>{h.para?.nome||'—'}</td><td>{new Date(h.criadoEm).toLocaleString()}</td></tr>
                ))}
              </tbody></table>
            </CardContent></Card>
          </>
        )}
      </div>
    </div>
  )
}
