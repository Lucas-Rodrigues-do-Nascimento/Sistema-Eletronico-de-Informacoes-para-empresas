'use client'

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function UploadDocumentoExterno({ processoId }: { processoId: number }) {
  const [submitting, setSubmitting] = useState(false)

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSubmitting(true)

    const form = e.currentTarget
    const fileInput = form.querySelector('input[name="arquivo"]') as HTMLInputElement
    const file = fileInput?.files?.[0]

    if (!file) return

    const formData = new FormData()
    formData.append("file", file)
    formData.append("tipo", "externo")

    const res = await fetch(`/api/processos/${processoId}/documentos`, {
      method: "POST",
      body: formData,
    })

    if (res.ok) {
      window.location.reload()
    } else {
      alert("Erro ao enviar documento")
      setSubmitting(false)
    }
  }

  return (
    <form
      onSubmit={handleUpload}
      className="flex items-center gap-2 px-2 py-1"
    >
      <input type="file" name="arquivo" className="text-sm" required />
      <Button type="submit" size="sm" variant="outline" disabled={submitting}>
        {submitting ? "Enviando..." : "Enviar"}
      </Button>
    </form>
  )
}
