// src/lib/utils.ts

import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import type { Processo, Documento, Movimentacao } from '@prisma/client'

// Utilitário de classes do Tailwind
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Tipagem estendida do processo com relacionamentos
export type ProcessoComRelacionamentos = Processo & {
  documentos: Documento[]
  movimentacoes: (Movimentacao & {
    de?: { nome: string }
    para?: { nome: string }
  })[]
}

// Função principal: separa os processos por setor
export function separarProcessosPorSetor(
  processos: ProcessoComRelacionamentos[],
  setorId: number
): {
  processosGerados: ProcessoComRelacionamentos[]
  processosRecebidos: ProcessoComRelacionamentos[]
} {
  const processosGerados: ProcessoComRelacionamentos[] = []
  const processosRecebidos: ProcessoComRelacionamentos[] = []

  for (const p of processos) {
    // 🔒 Garante que o processo tem ID válido
    if (!p.id || isNaN(Number(p.id))) continue

    // 🧠 Verifica se o processo está ativo no setor atual
    const aindaAtivoNoSetor = p.movimentacoes.some(
      (m) => m.paraSetor === setorId && m.ativo
    )

    // 🏷️ Verifica se o processo foi criado nesse setor
    const foiGeradoAqui = p.movimentacoes.some(
      (m) => m.deSetor === setorId && m.paraSetor === setorId
    )

    if (aindaAtivoNoSetor) {
      if (foiGeradoAqui) {
        processosGerados.push(p)
      } else {
        processosRecebidos.push(p)
      }
    }
  }

  return {
    processosGerados,
    processosRecebidos,
  }
}
